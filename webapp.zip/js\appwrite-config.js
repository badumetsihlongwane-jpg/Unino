// appwrite-config.js
// Replace firebase-config.js with this file in your HTML.

const APPWRITE_ENDPOINT = 'https://syd.cloud.appwrite.io/v1';
const APPWRITE_PROJECT_ID = '69b4202c00370d4748d6';
const APPWRITE_DATABASE_ID = 'unibo_db'; // Note: Must match exactly what's created in appwrite-init.mjs

// Initialize Appwrite Web SDK
const client = new Appwrite.Client()
    .setEndpoint(APPWRITE_ENDPOINT)
    .setProject(APPWRITE_PROJECT_ID);

const account = new Appwrite.Account(client);
const databases = new Appwrite.Databases(client);
const storage = new Appwrite.Storage(client);
window.auth = account;
window.storage = storage;

// ==========================================
// FIREBASE FIRESTORE ADAPTER FOR APPWRITE
// ==========================================
// This adapter mimics the Firebase Web V8 SDK to prevent needing to rewrite thousands of lines of code.

class AppwriteDocAdapter {
    constructor(dbId, colId, docId) {
        this.dbId = dbId;
        this.colId = colId;
        this.docId = docId;
    }
    
    async get() {
        try {
            const doc = await databases.getDocument(this.dbId, this.colId, this.docId);
            return { exists: true, id: doc.$id, data: () => doc, ref: this };
        } catch (e) {
            if (e.code === 404) return { exists: false, id: this.docId, data: () => null, ref: this };
            throw e;
        }
    }
    
    async set(data, options = {}) {
        const id = this.docId || Appwrite.ID.unique();
        if (options.merge) {
            try { return await databases.updateDocument(this.dbId, this.colId, id, data); }
            catch (e) { if (e.code === 404) return await databases.createDocument(this.dbId, this.colId, id, data); else throw e; }
        } else {
            return await databases.createDocument(this.dbId, this.colId, id, data);
        }
    }
    
    async update(data) {
        return await databases.updateDocument(this.dbId, this.colId, this.docId, data);
    }
    
    async delete() {
        return await databases.deleteDocument(this.dbId, this.colId, this.docId);
    }
    
    collection(subColId) {
        // Appwrite doesn't have native subcollections. We use a flat architecture and filter by parentId.
        // We will mock this by configuring queries that filter by the parent document ID.
        // E.g., db.collection('posts').doc('123').collection('comments') becomes db.collection('comments').where('postId', '==', '123')
        throw new Error("Subcollections are not supported natively in this adapter. Restructure to flat collections with relationships.");
    }
}

class AppwriteQueryAdapter {
    constructor(dbId, colId) {
        this.dbId = dbId;
        this.colId = colId;
        this.queries = [];
    }
    
    where(field, op, value) {
        if (op === '==') this.queries.push(Appwrite.Query.equal(field, value));
        else if (op === '>') this.queries.push(Appwrite.Query.greaterThan(field, value));
        else if (op === '>=') this.queries.push(Appwrite.Query.greaterThanEqual(field, value));
        else if (op === '<') this.queries.push(Appwrite.Query.lessThan(field, value));
        else if (op === '<=') this.queries.push(Appwrite.Query.lessThanEqual(field, value));
        else if (op === 'in') this.queries.push(Appwrite.Query.equal(field, value)); // Appwrite equal supports arrays
        else if (op === 'array-contains') this.queries.push(Appwrite.Query.search(field, value)); // Or equal depending on attribute type
        return this;
    }
    
    orderBy(field, dir = 'asc') {
        if (dir === 'desc') this.queries.push(Appwrite.Query.orderDesc(field));
        else this.queries.push(Appwrite.Query.orderAsc(field));
        return this;
    }
    
    limit(num) {
        this.queries.push(Appwrite.Query.limit(num));
        return this;
    }
    
    async get() {
        const res = await databases.listDocuments(this.dbId, this.colId, this.queries);
        return {
            empty: res.total === 0,
            size: res.total,
            docs: res.documents.map(d => ({ id: d.$id, exists: true, data: () => d, ref: new AppwriteDocAdapter(this.dbId, this.colId, d.$id) }))
        };
    }
    
    onSnapshot(onNext, onError) {
        // Mock fallback to fetch once and subscribe
        this.get().then(onNext).catch(onError);
        const sub = client.subscribe(`databases.${this.dbId}.collections.${this.colId}.documents`, response => {
            this.get().then(onNext).catch(onError);
        });
        return () => sub(); // Unsubscribe function
    }
}

class AppwriteCollectionAdapter {
    constructor(dbId, colId) {
        this.dbId = dbId;
        this.colId = colId;
    }
    
    doc(id) { return new AppwriteDocAdapter(this.dbId, this.colId, id); }
    async add(data) {
        const doc = await databases.createDocument(this.dbId, this.colId, Appwrite.ID.unique(), data);
        return new AppwriteDocAdapter(this.dbId, this.colId, doc.$id);
    }
    
    // Query methods pass through to QueryAdapter
    where(f, o, v) { return new AppwriteQueryAdapter(this.dbId, this.colId).where(f, o, v); }
    orderBy(f, d) { return new AppwriteQueryAdapter(this.dbId, this.colId).orderBy(f, d); }
    limit(n) { return new AppwriteQueryAdapter(this.dbId, this.colId).limit(n); }
    async get() { return new AppwriteQueryAdapter(this.dbId, this.colId).get(); }
    onSnapshot(n, e) { return new AppwriteQueryAdapter(this.dbId, this.colId).onSnapshot(n, e); }
}

window.db = {
    collection: (colId) => new AppwriteCollectionAdapter(APPWRITE_DATABASE_ID, colId),
    getDocument: databases.getDocument.bind(databases),
    createDocument: databases.createDocument.bind(databases),
    updateDocument: databases.updateDocument.bind(databases),
    deleteDocument: databases.deleteDocument.bind(databases),
    listDocuments: databases.listDocuments.bind(databases),
    runTransaction: async (cb) => {
        // Appwrite doesn't have true transactions yet. We mock it.
        const txMock = {
            get: async (ref) => ref.get(),
            set: (ref, data) => ref.set(data),
            update: (ref, data) => ref.update(data),
            delete: (ref) => ref.delete()
        };
        return await cb(txMock);
    }
};

window.firebase = {
    firestore: {
        FieldValue: {
            serverTimestamp: () => new Date().toISOString(),
            increment: (amount = 1) => amount,
            arrayUnion: (val) => val, 
            arrayRemove: (val) => val,
        },
        FieldPath: {
            documentId: () => '$id'
        }
    }
};
window.FieldVal = window.firebase.firestore.FieldValue;
